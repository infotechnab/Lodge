<div class="menuItem">
                    <ul class="list">
                                            
        <?php

            $this->load->helper('viewMenuHelper');

            fetch_menu (query(0));

        ?>
                    </ul>

                </div>