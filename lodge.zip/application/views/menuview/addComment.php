<p>Comment:<br />
      <textarea name="page_content" id="area1" cols="50" rows="5" placeholder="leave a comment" ><?php echo set_value('page_content'); ?></textarea>
  </p>
   <input type="submit" value="Submit" />
  <?php echo form_close();?>