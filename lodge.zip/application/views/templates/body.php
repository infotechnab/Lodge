 <div id="container">
              <div id="leftContainer">
                  <div id="topLeftContainer">
                      
                      <?php if(!empty($query))
                      {
     foreach ($query as $data)
     { ?>
         <div id="rates">
             <img src="<?php echo base_url().'contents/uploads/images/'.$data->image; ?>" width="50" height="50" />
                          <h1><?php echo $data->post_title; ?></h1>
                          <p><?php echo $data->post_summary; ?> </p>
                      </div>
    <?php }
                      }
?>
                      
<!--                      <div id="rates">
                          <h1>Best Rates</h1>
                          <p>Chitwan Gaida Lodge provide best rates & facilities in Chitwan, Kathmandu, Nepal. </p>
                      </div>
                      
                      <div id="friendlines">
                          <h1>Friendliness</h1>
                          <p>We provide friendly behavior to our valued customers.</p>
                      </div>
                      
                      <div id="location">
                          <h1>Location</h1>
                          <p>We have central location presence in Sauraha. Sight Seen, elephant riding, bird watching are just right way from our location.</p>
                      </div>-->
                      
                      
                      
                  </div>
                  
                  <!-- best rates, friendliness, location is closed here-->
                  
                   <div class="clear"></div>
                  
                  
                  <div id="bottomLeftContainer">
                      <div id="leftBottomLeftContainer">
                          <h2>Welcome to Chitwan Gaida Lodge</h2>
                          <p>
                              Experiencing tourism history of the 3 decades, Chitwan Gaida Lodge is the pioneer in this field. It spreads over an area of 72,000 sq ft. The lodge is centrally located at the northern edge of the RCNP, a well-known site for the wildlife and hardly 3-4min walk up to the park entrance office from the CGL. It has a peaceful and tranquil area by the bank of Rapti river and just beside the park entrance. It is easily accessed from the east-west national highway which is only 6km away from the small town called Tandi Bazaar or Sauraha Chowk, where the roads get forked and turn towards the south. CGL has fully furnished rooms (a/c or normal) with attached bathrooms, including 24hours of hot/cold water. It has a cool shady garden with mature flora's which provides food for the different feeding bird parties. We can watch them feed every morning and in the late afternoons from the balcony of the private rooms provided by the CGL giving the feeling of being in the wild environment itself.
                          </p>
                      </div>
                      <!-- Chitwan gaida lodge home closed-->
                      
                      <div id="rightBottomLeftContainer">
<!--                         <img src="<?php echo base_url(); ?>contents/images/testimonials.png" /> -->
                          <div id="TA_certificateOfExcellence501" class="TA_certificateOfExcellence">
<ul id="uOk1NU" class="TA_links 1noHtv">
<li id="6binj6V" class="1nQN9WUdro">
<a target="_blank" href="http://www.tripadvisor.com/"><img src="http://www.tripadvisor.com/img/cdsi/img2/awards/CoE2014_WidgetAsset-14348-2.png" alt="TripAdvisor" class="widCOEImg" id="CDSWIDCOELOGO"/></a>
</li>
</ul>
</div>
<script src="http://www.jscache.com/wejs?wtype=certificateOfExcellence&amp;uniq=501&amp;locationId=2083553&amp;lang=en_US&amp;year=2014"></script>

<h4>Testimonials</h4>
<div id="TA_selfserveprop611" class="TA_selfserveprop">
<ul id="tJZLiz7A" class="TA_links C1HTRFZ10Y">
<li id="g7lqw4S240" class="vv4IsH4bls">
<a target="_blank" href="http://www.tripadvisor.com/"><img src="http://www.tripadvisor.com/img/cdsi/img2/branding/150_logo-11900-2.png" alt="TripAdvisor"/></a>
</li>
</ul>
</div>
<script src="http://www.jscache.com/wejs?wtype=selfserveprop&amp;uniq=611&amp;locationId=2083553&amp;lang=en_US&amp;rating=true&amp;nreviews=5&amp;writereviewlink=true&amp;popIdx=true&amp;iswide=false&amp;border=true"></script>

                      </div>
                      
                      <!-- testimonials is closed here-->
                      
                      <div class="clear"></div>
                  </div>
              
                  <!-- testimonials and chitwan gaida lodge home closed here-->
              
              
              
              </div>
              
              <!-- Leftside container is closed here-->
              
              
                 
              <div id="rightContainer">
                  
                  <div>
                       <?php foreach ($event as $sideEvent){
        $date=date("Y-m-d", strtotime($sideEvent->date));
        $time=date("h:i A", strtotime($sideEvent->date));
        $setTime=date("G:i:s", strtotime($sideEvent->date));
         $noTime="0:00:00";      
        		                ?>
            <div class="event-list">
                <a style="color:#000;" href="<?php echo base_url()."index.php/home/eventDetails/".$sideEvent->id ?>"><div class='sidebarContentNext' style="z-index: 1;">
                
                <?php if (strlen($sideEvent->image)>2){ ?>
		                    <div class="cartImage" style="float: left; width: 14%; min-height: 40px; margin: -1px; padding: 0px;">
		                       <img src="<?php echo base_url().'contents/uploads/images/'.$sideEvent->image; ?>" width="51" height="51"  /> 
		                    </div>
                <?php } ?>
		                    <div class="eventTitle">
		                       
                                        <h4><?php echo mb_strimwidth($sideEvent->title, 0, 37, "..."); ?></h4>
                                        <p>On <?php echo $date;  ?> <?php if($setTime!==$noTime){ echo'at'. $time;} else{}  ?></p>
                                       
                                       
                                        
		                    </div> 
                                    
		                     
                                          
		                </div></a>
       </div>
                            <?php } ?>
                  </div> 
                  
                  
                  
                  
                  <iframe src="//www.facebook.com/plugins/likebox.php?href=https%3A%2F%2Fwww.facebook.com%2Fchitwangaidalodge&amp;width&amp;height=290&amp;colorscheme=light&amp;show_faces=true&amp;header=true&amp;stream=false&amp;show_border=true" scrolling="no" frameborder="0" style="border:none; overflow:hidden; height:290px;" allowTransparency="true"></iframe>         
                  
<!--            <img src="<?php echo base_url(); ?>contents/images/tripAdvisor.png" /> -->

                  <div id="TA_cdswritereviewlg691" class="TA_cdswritereviewlg">
<ul id="iz4U9Q18BmO" class="TA_links EvFsAuef">
<li id="Kury4aW28BPK" class="mRpP46JIt4Gr">
<a target="_blank" href="http://www.tripadvisor.com/"><img src="http://www.tripadvisor.com/img/cdsi/img2/branding/medium-logo-12097-2.png" alt="TripAdvisor"/></a>
</li>
</ul>
</div>
<script src="http://www.jscache.com/wejs?wtype=cdswritereviewlg&amp;uniq=691&amp;locationId=2083553&amp;lang=en_US&amp;border=true"></script>

                  
                  
                  
                  
                  
                  
              </div>
              <div class="clear"></div>    
          </div> 
          <div class="clear"></div>
          <!-- container div closed -->
          
         
