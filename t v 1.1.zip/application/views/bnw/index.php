        
        <div class="rightSide">
            <h2>Dashboard >> Home</h2> 
            <hr class="hr-gradient"/>
            <style>
               
                .quick_sale_product{
                    width: 100%;
                }
                .quick{
                    width: 48%;
                    float: right;
                }
                .sale_product{
                    width: 48%;
                    float: left;
                }
                .sale{
                    width: 98%;
                }
                .product{
                    width: 98%;
                }
            </style>
            <div class="quick_sale_product">
       
        
    
    
    
   
       
